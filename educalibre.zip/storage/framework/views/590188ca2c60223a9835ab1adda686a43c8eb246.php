<div>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="hover:text-purple-800" href="<?php echo e(route('article.show', $article)); ?>"><h1 class="font-serif font-bold text-3xl px-2 py-3 "><?php echo e($article->title); ?></h1></a>
        <p class="font-serif px-2"><?php echo e(Str::limit($article->subtitle, 160)); ?></p>
        <hr>
        <p class="px-2"><span class="font-bold" ><?php echo e($article->teacher->name); ?></span>  <span>6 Comentarios</span></p>
        <img class="h-100 w-full bg-cover" src="<?php echo e(Storage::url($article->image->url)); ?>" alt="">
        <div class="py-2 px-2 font-serif">
            <?php echo Str::limit($article->description, 300); ?>

        </div>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $destacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destacado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <div class="container grid grid-cols-1 lg:grid-cols-2 gap-2 py-2 ">
                <img class="h-48 w-full bg-cover " src="<?php echo e(Storage::url($destacado->image->url)); ?>" alt="">
                <div>
                    <a class="hover:text-purple-800" href="<?php echo e(route('article.show', $destacado)); ?>"><p class="text-gray-800 font-serif text-3xl px-3 "><?php echo e($destacado->title); ?></p></a>
                    <p class="px-3"><span class="font-bold" ><?php echo e($destacado->teacher->name); ?></span>  <span>6 Comentarios</span></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $editorials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editorial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr>
        <h1 class="text-2xl text-red-600 mt-2">Editorial</h1>
        <a class="hover:text-purple-800" href="<?php echo e(route('article.editorial', $editorial)); ?>"><h1 class="font-serif text-3xl px-3 mb-2"><?php echo e($editorial->title); ?></h1></a>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $opinions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opinion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <div class="container grid grid-cols-1 lg:grid-cols-2 gap-2 py-2">
                <div class="bg-red-200">
                    <img class="h-48 w-full bg-cover" src="<?php echo e(Storage::url($opinion->image->url)); ?>" alt="">
                </div>
                <div>
                    <a class="hover:text-purple-800" href="<?php echo e(route('article.editorial', $opinion)); ?>"><p class="font-serif text-3xl px-3"><?php echo e($opinion->title); ?></p></a>
                    <p class="px-3"><span class="font-bold" ><?php echo e($opinion->teacher->name); ?></span>  <span>6 Comentarios</span></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
</div>

<?php /**PATH C:\xampp\htdocs\educalibre\resources\views/livewire/articles-index.blade.php ENDPATH**/ ?>