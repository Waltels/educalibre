

<?php $__env->startSection('title', 'educaLibre'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Escritorio</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Telefono</th>
                    <th>Asunto</th>
                    <th>Mensaje</th>
                    <th colspan="2"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($contact->id); ?>

                        </td>
                        <td>
                            <?php echo e($contact->name); ?>

                        </td>
                        <td>
                            <?php echo e($contact->email); ?>

                        </td>
                        <td>
                            <?php echo e($contact->tel); ?>

                        </td>
                        <td>
                            <?php echo e($contact->asunto); ?>

                        </td>
                        <td>
                            <?php echo e($contact->detalle); ?>

                        </td>
                        <td width="10px">
                            <a class="btn btn-primary btn-sm" href="#">Responder</a>
                        </td>
                        <td width="10px">
                            <form action="#" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>

                                <button class="btn btn-danger btn-sm" type="submit">Eliminar</button>

                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\educalibre\resources\views/pages/contact/index.blade.php ENDPATH**/ ?>