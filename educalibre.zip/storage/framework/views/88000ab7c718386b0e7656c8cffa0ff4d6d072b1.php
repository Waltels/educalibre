<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'educalibre')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/boton.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/material-dashboard.css?v=2.2.2')); ?>">
        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
        <!-- CSS Just for demo purpose, don't include it in your project -->
        <link rel="stylesheet" href="<?php echo e('asset/demo.css'); ?>"  />

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/boton.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap-material-design.min.js')); ?>"></script>
        


  
        
    </head>
    <body class="font-sans antialiased">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.banner','data' => []]); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <div class="min-h-screen bg-gray-100">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu')->html();
} elseif ($_instance->childHasBeenRendered('PDCgH3V')) {
    $componentId = $_instance->getRenderedChildComponentId('PDCgH3V');
    $componentTag = $_instance->getRenderedChildComponentTagName('PDCgH3V');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PDCgH3V');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu');
    $html = $response->html();
    $_instance->logRenderedChild('PDCgH3V', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Page Content -->
            <div class="container py-8 grid grid-cols-5 gap-4">
                <aside>
                    <h1 class="font-bold text-xl mb-4 text-center">Edición del Artículo</h1>
                    <ul class="py-2">
                        <li class="leading-7 mb-1 border-l-4 <?php if(Request::url() == route('editor.articles.edit', $article)): ?> border-indigo-400 <?php else: ?> border-transparent <?php endif; ?>  pl-2 py-2">
                            <a href="<?php echo e(route('editor.articles.edit', $article)); ?>">Información del Artículo</a>
                        </li>
                        <?php if($article->observation): ?>
                            <li class="leading-7 mb-1 border-l-4 <?php if(Request::url() == route('editor.articles.observation', $article)): ?> border-indigo-400 <?php else: ?> border-transparent <?php endif; ?> pl-2">
                                <a href="<?php echo e(route('editor.articles.observation', $article)); ?>">Observaciones del Artículo</a>
                            </li>
                        <?php endif; ?>   
                    </ul>
                    <?php switch($article->status):
                    case (1): ?>
                        <form action="<?php echo e(route('editor.articles.status', $article)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger" type="submit">Solicitar revisión</button>
                        </form>
                        <?php break; ?>
                    <?php case (2): ?>
                        <div class="card text-red-300 px-4">
                            <div class="card-body px-2">
                                <p class="text-blue-800 text-center">Este artículo fue enviado a revisión, nuestro equipo de editores analizara su trabajo y le presentara alguna observacion si existe o se publicara.</p>
                                <p class="bg-gray-100 px-0 text-gray-800  font-bold text-lg text-center"> <span class="text-lx text-red-600">educa</span><span class="text-blue-800">Libre</span> agradece su aporte a nuestro blog.</p>
                            </div>
                        </div>
                        <?php break; ?>
        
                    <?php case (3): ?>
                        <div class="card text-green-300">
                            <div class="card-body">
                                <p class="text-blue-800 text-center">Este artículo se encuentra publicado en nuestra web educaLibre.com</p>
                                <p class="bg-gray-100 px-0 text-gray-800  font-bold text-lg text-center"> <span class="text-lx text-red-600">educa</span><span class="text-blue-800">Libre</span> agradece su aporte a nuestro blog.</p>
                            </div>
                        </div>
                        <?php break; ?>
                    <?php default: ?>
                        
                <?php endswitch; ?>
        
        
                </aside>
                <main class="col-span-4 card">
                    <?php echo e($slot); ?>

        
                </main>
        
            </div>

            <!-- endpage Content -->
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

        <?php if(isset($js)): ?>
            <?php echo e($js); ?>

        <?php endif; ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\educalibre\resources\views/layouts/editor.blade.php ENDPATH**/ ?>