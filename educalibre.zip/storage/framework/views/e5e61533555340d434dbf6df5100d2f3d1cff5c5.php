<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="grid grid-cols-1 lg:grid-cols-5 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 gap-4 py-4">
        <figure class="col-span-4 px-3">
            <div class="flex">
                <i class="material-icons text-red-500">storage</i>
                      <h4 class="text-red-600 font-bold">-- <?php echo e($editorial->category->name); ?> </h4>
                <i class="material-icons text-red-500">chevron_right</i>
            </div> 
            <h2 class=" leading-10 py-2 font-bold font-serif"><?php echo e($editorial->title); ?></h2>
            <p class="mb-1"><span class="font-bold text-red-700">Escrito por: <?php echo e($editorial->teacher->name); ?></span> / educalibre@gmail.com</p>
            <p>Publicado el: <?php echo e($editorial->created_at); ?></p>
            <i class="fab fa-whatsapp"></i>
            <div class="py-2  font-serif text-lg text-justify">
                <?php echo $editorial->description; ?>

            </div>
            <h5 class=" py-2">Escrito por: <?php echo e($editorial->teacher->name); ?></h5>
            
            
            
        </figure>
        <div class="bg-gray-200">
          
        </div>
    </section>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\educalibre\resources\views/articles/editorial.blade.php ENDPATH**/ ?>