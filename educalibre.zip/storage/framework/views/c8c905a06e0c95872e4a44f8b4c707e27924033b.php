<?php if (isset($component)) { $__componentOriginal3c0448b937bbb1f49ef7cd1a6dd57c31a9deb378 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\EditorLayout::class, ['article' => $article]); ?>
<?php $component->withName('editor-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="card-body">
        <h1 class="text-2xl font-bold">INFORMACION DEL ARTICULO</h1>
        <hr class="mt-2 mb-8">
        <?php echo Form::model($article, ['route'=>['editor.articles.update', $article], 'method'=>'put', 'files'=> true]); ?>

            
            <?php echo $__env->make('editor.articles.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="flex justify-end">
                <?php echo Form::submit('Actualizar informacion', ['class'=> 'btn btn-primary']); ?>

             </div>
        <?php echo Form::close(); ?>

    </div>

     <?php $__env->slot('js', null, []); ?> 
        <script src="https://cdn.ckeditor.com/ckeditor5/24.0.0/classic/ckeditor.js"></script>
        <script src="<?php echo e(asset('js/editor/articles/form.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal3c0448b937bbb1f49ef7cd1a6dd57c31a9deb378)): ?>
<?php $component = $__componentOriginal3c0448b937bbb1f49ef7cd1a6dd57c31a9deb378; ?>
<?php unset($__componentOriginal3c0448b937bbb1f49ef7cd1a6dd57c31a9deb378); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\educalibre\resources\views/editor/articles/edit.blade.php ENDPATH**/ ?>