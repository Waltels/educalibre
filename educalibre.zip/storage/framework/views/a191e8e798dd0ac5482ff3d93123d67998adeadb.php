<div>



    <?php echo Form::open(['class'=> 'bg-white shadow-md rounded pt-6 pb-8 mb-4 px-2']); ?>

        <div class="mb-2">
            <?php echo Form::label('name', 'Nombre',['class'=> 'block text-gray-700 text-sm font-bold mb-2']); ?>

            <?php echo Form::text('name', null,['class'=> 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline']); ?>

        </div>
        <div class="mb-2">
            <?php echo Form::label('name', 'Correo',['class'=> 'block text-gray-700 text-sm font-bold mb-2']); ?>

            <?php echo Form::email('name', null, ['class'=>'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline']); ?>

        </div>
        <div class="mb-2">
            <?php echo Form::label('name', 'N° de Teléfono',['class'=> 'block text-gray-700 text-sm font-bold mb-2']); ?>

            <?php echo Form::text('name', null,['class'=> 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline']); ?>

        </div>
        <div class="mb-2">
            <?php echo Form::label('name', 'Asunto',['class'=> 'block text-gray-700 text-sm font-bold mb-2']); ?>

            <?php echo Form::text('name', null,['class'=> 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline']); ?>

        </div>
        <div class="mb-2">
            <?php echo Form::label('name', 'Mensaje',['class'=> 'block text-gray-700 text-sm font-bold mb-2']); ?>

            <?php echo Form::textarea('name', null, ['class'=> 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline', 'rows'=>'3']); ?>

        </div>
        <div class="flex items-center justify-between">
            <?php echo Form::submit('enviar', ['class'=> 'bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline']); ?>


        </div>
        <?php echo Form::close(); ?>


</div>
<?php /**PATH C:\xampp\htdocs\educalibre\resources\views/livewire/contact-index.blade.php ENDPATH**/ ?>