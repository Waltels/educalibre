<div class="mb-4">
    <?php echo Form::label('title', 'Tútulo del Artículo'); ?>  
    <?php echo Form::text('title', null, ['class'=>'form-input block w-full mt-1'.($errors->has('title') ? ' border-red-600' : '')]); ?>

    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <strong class="text-sm text-red-600"><?php echo e($message); ?></strong>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-4">
    <?php echo Form::label('slug', 'Slug del Artículo'); ?>  
    <?php echo Form::text('slug', null, ['readonly'=>'readonly','class'=>'form-input block w-full mt-1'.($errors->has('title') ? ' border-red-600' : '')]); ?>

    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <strong class="text-sm text-red-600"><?php echo e($message); ?></strong>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-4">
    <?php echo Form::label('subtitle', 'Subtútulo del Artículo'); ?>  
    <?php echo Form::text('subtitle', null, ['class'=>'form-input block w-full mt-1'.($errors->has('title') ? ' border-red-600' : '')]); ?>

    <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <strong class="text-sm text-red-600"><?php echo e($message); ?></strong>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-4">
    <?php echo Form::label('description', 'Contenido del Artículo'); ?>

    <?php echo Form::textarea('description', null, ['class'=>'form-input block w-full mt-1'. ($errors->has('description') ? ' border-red-600' : '')]); ?>

    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <strong class="text-sm text-red-600"><?php echo e($message); ?></strong>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="grid grid-cols-3 gap-4">
    <div class="col-span-1">
        <?php echo Form::label('category_id', 'Sección :'); ?>

        <?php echo Form::select('category_id', $categories, null, ['class'=>'form-input block w-full mt-1']); ?>

    </div>
</div>
<h1 class="text-2xl font-bold mt-8 mb-2">Imagen del artículo</h1>
<div class="grid grid-cols-2 gap-4">

    <figure>
        <?php if(isset($article->image)): ?>
        <img id="picture" class="w-full h-64 object-cover object-center" src="<?php echo e(Storage::url($article->image->url)); ?>" alt="">
          <?php else: ?>
           <img id="picture" class="w-full h-64 object-cover object-center" src="https://www.pexels.com/photo/5965857/download/" alt="">   
          <?php endif; ?>   
    </figure>
    
    <div>
        <div>
            <?php echo Form::label('desfoto', 'Descripción de la imagen'); ?>  
            <?php echo Form::textarea('desfoto', null, ['class'=>'form-input block w-full mt-1'.($errors->has('desfoto') ? ' border-red-600' : '')]); ?>

        </div>
        <?php $__errorArgs = ['desfoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-sm text-red-600"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <p class="mt-4">Seleccione la imagen destacada del artículo que decea publicar</p>
        <?php echo Form::file('file', ['class'=>'form-input w-full'. ($errors->has('file') ? ' border-red-600' : ''), 'id'=>'file', 'accept'=>'image/*']); ?>

        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-sm text-red-600"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\educalibre\resources\views/editor/articles/partials/form.blade.php ENDPATH**/ ?>