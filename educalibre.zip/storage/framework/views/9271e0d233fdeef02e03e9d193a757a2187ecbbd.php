<div>
    <div class="grid grid-cols-1 divide-y divide-red-500">
        <div>
            <h1 class="text-2xl text-red-600">Nuestras secciones</h1>
        </div>       
    <div class="grid grid-cols-1">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                <div class="card-header card-header-tabs card-header-info">
                    <div class="nav-tabs-navigation">
                        <div class="nav-tabs-wrapper">

                            <ul class="nav nav-tabs" data-tabs="tabs">
                            <li class="nav-item">
                                <a class="nav-link active" href="#educacion" data-toggle="tab">
                                <i class="material-icons">people</i> Educación
                                <div class="ripple-container"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#cultura" data-toggle="tab">
                                <i class="material-icons">code</i> cultura
                                <div class="ripple-container"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#deportes" data-toggle="tab">
                                <i class="material-icons">sports</i> deportes
                                <div class="ripple-container"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#polsin" data-toggle="tab">
                                <i class="material-icons">spoke</i> político sindical
                                <div class="ripple-container"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#libre" data-toggle="tab">
                                <i class="material-icons">co_present</i> libre
                                <div class="ripple-container"></div>
                                </a>
                            </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="card-body bg-white">
                    <div class="tab-content bg-white px-4">
                        <div class="tab-pane active bg-white px-0" id="educacion">
                            <div class="w-full bg-white rounded container grid grid-cols-1 lg:grid-cols-3 gap-4 px-0">
                                <?php $__currentLoopData = $educacions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">
                                    <div class="w-full flex justify-between p-3 relative ">
                                        <div class="flex">
                                        <div class="rounded-full h-8 w-8  flex items-center justify-center overflow-hidden">
                                            <img src="https://avatars0.githubusercontent.com/u/38799309?v=4" alt="profilepic">
                                        </div>
                                        <span class="pt-1 ml-2 font-bold text-sm"><?php echo e($educacion->teacher->name); ?></span>
                                        </div>
                                        <span class="px-2 hover:bg-gray-300 cursor-pointer rounded"><i class="fas fa-ellipsis-h pt-2 text-lg"></i>555</span>
                                    </div>
                                    <img class="h-60 w-full bg-cover" src="<?php echo e(Storage::url($educacion->image->url)); ?>">
                                    <div class="px-2 pb-2">
                                        <div class="pt-1">
                                            <div class="py-4">
                                                <a class="hover:text-blue-800" href="<?php echo e(route('article.show', $educacion)); ?>"><span class="text-gary-800 font-serif text-3xl px-2 py-3 leading-6"><?php echo e($educacion->title); ?></span></a> 
                                            </div>
                                        </div>
                                        
                                        <div class="absolute bottom-0 px-1 text-sm mb-2 text-gray-700 cursor-pointer font-medium mt-3 ">10 de octubre de 2021</div>
                                    </div>
                                </div> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                        </div>
                        <div class="tab-pane bg-white px-0" id="cultura">
                            <div class="w-full bg-white rounded container grid grid-cols-1 lg:grid-cols-3 gap-4 px-0">
                                <?php $__currentLoopData = $culturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cultura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">
                                    <div class="relative w-full flex justify-between p-3 ">
                                        <div class="flex">
                                        <div class="rounded-full h-8 w-8  flex items-center justify-center overflow-hidden">
                                            <img src="https://avatars0.githubusercontent.com/u/38799309?v=4" alt="profilepic">
                                        </div>
                                        <span class="pt-1 ml-2 font-bold text-sm"><?php echo e($cultura->teacher->name); ?></span>
                                        </div>
                                        <span class="px-2 hover:bg-gray-300 cursor-pointer rounded"><i class="fas fa-ellipsis-h pt-2 text-lg"></i>555</span>
                                    </div>
                                    <img class="h-60 w-full bg-cover" src="<?php echo e(Storage::url($cultura->image->url)); ?>">
                                    <div class="px-2 pb-2">
                                        <div class="pt-1">
                                            <div class="py-4">
                                               <a class="hover:text-blue-800" href="<?php echo e(route('article.show', $cultura)); ?>"><span class="text-gray-800 font-serif text-3xl px-2 py-3 leading-6"><?php echo e($cultura->title); ?></span></a> 
                                            </div>
                                        </div>
                                        
                                        <div class="absolute bottom-0 px-1 text-sm mb-2 text-gray-700 cursor-pointer font-medium mt-3 "><?php echo e($cultura->created_at); ?></div>
                                    </div>
                                </div> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                        </div>
                        <div class="tab-pane bg-white px-0" id="deportes">
                            <div class="w-full bg-white rounded container grid grid-cols-1 lg:grid-cols-3 gap-4 px-0">
                                <?php $__currentLoopData = $deportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">
                                    <div class="relative w-full flex justify-between p-3 ">
                                        <div class="flex">
                                        <div class="rounded-full h-8 w-8  flex items-center justify-center overflow-hidden">
                                            <img src="https://avatars0.githubusercontent.com/u/38799309?v=4" alt="profilepic">
                                        </div>
                                        <span class="pt-1 ml-2 font-bold text-sm"><?php echo e($deporte->teacher->name); ?></span>
                                        </div>
                                        <span class="px-2 hover:bg-gray-300 cursor-pointer rounded"><i class="fas fa-ellipsis-h pt-2 text-lg"></i>555</span>
                                    </div>
                                    <img class="h-60 w-full bg-cover" src="<?php echo e(Storage::url($deporte->image->url)); ?>">
                                    <div class="px-2 pb-2">
                                        <div class="pt-1">
                                            <div class="py-4">
                                               <a class="hover:text-blue-800" href="<?php echo e(route('article.show', $deporte)); ?>"><span class="text-gray-800 font-serif text-3xl px-2 py-3 leading-6"><?php echo e($deporte->title); ?></span></a> 
                                            </div>
                                        </div>
                                        
                                        <div class="absolute bottom-0 px-1 text-sm mb-2 text-gray-700 cursor-pointer font-medium mt-3 "><?php echo e($deporte->created_at); ?></div>
                                    </div>
                                </div> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                        </div>
                        <div class="tab-pane bg-white px-0" id="polsin">
                            <div class="w-full bg-white rounded container grid grid-cols-1 lg:grid-cols-3 gap-4 px-0">
                                <?php $__currentLoopData = $polsins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $polsin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">
                                    <div class="relative w-full flex justify-between p-3 ">
                                        <div class="flex">
                                        <div class="rounded-full h-8 w-8  flex items-center justify-center overflow-hidden">
                                            <img src="https://avatars0.githubusercontent.com/u/38799309?v=4" alt="profilepic">
                                        </div>
                                        <span class="pt-1 ml-2 font-bold text-sm"><?php echo e($polsin->teacher->name); ?></span>
                                        </div>
                                        <span class="px-2 hover:bg-gray-300 cursor-pointer rounded"><i class="fas fa-ellipsis-h pt-2 text-lg"></i>555</span>
                                    </div>
                                    <img class="h-60 w-full bg-cover" src="<?php echo e(Storage::url($polsin->image->url)); ?>">
                                    <div class="px-2 pb-2">
                                        <div class="pt-1">
                                            <div class="py-4">
                                               <a class="hover:text-blue-800" href="<?php echo e(route('article.show', $polsin)); ?>"><span class="text-gray-800 font-serif text-3xl px-2 py-3 leading-6"><?php echo e($polsin->title); ?></span></a> 
                                            </div>
                                        </div>
                                        
                                        <div class="absolute bottom-0 text-sm mb-2 text-gray-700 cursor-pointer font-medium mt-3 "><?php echo e($polsin->created_at); ?></div>
                                    </div>
                                </div> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                        </div>
                        <div class="tab-pane bg-white px-0" id="libre">
                            <div class="w-full bg-white rounded container grid grid-cols-1 lg:grid-cols-3 gap-4 px-0">
                                <?php $__currentLoopData = $libres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">
                                    <div class="relative w-full flex justify-between p-3 ">
                                        <div class="flex">
                                        <div class="rounded-full h-8 w-8  flex items-center justify-center overflow-hidden">
                                            <img src="https://avatars0.githubusercontent.com/u/38799309?v=4" alt="profilepic">
                                        </div>
                                        <span class="pt-1 ml-2 font-bold text-sm"><?php echo e($libre->teacher->name); ?></span>
                                        </div>
                                        <span class="px-2 hover:bg-gray-300 cursor-pointer rounded"><i class="fas fa-ellipsis-h pt-2 text-lg"></i>555</span>
                                    </div>
                                    <img class="h-60 w-full bg-cover" src="<?php echo e(Storage::url($libre->image->url)); ?>">
                                    <div class="px-2 pb-2">
                                        <div class="pt-1">
                                            <div class="py-4">
                                               <a class="hover:text-blue-800" href="<?php echo e(route('article.show', $libre)); ?>"><span class="text-gray-800 font-serif text-3xl px-2 py-3 leading-6"><?php echo e($libre->title); ?></span></a> 
                                            </div>
                                        </div>
                                        
                                        <div class="absolute bottom-0 px-1 text-sm mb-2 text-gray-700 cursor-pointer font-medium mt-3 "><?php echo e($libre->created_at); ?></div>
                                    </div>
                                </div> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
    </div>   
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\educalibre\resources\views/livewire/secciones-index.blade.php ENDPATH**/ ?>