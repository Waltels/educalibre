<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<section>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-cover container grid grid-cols-1 lg:grid-cols-2"style="background-image: url(<?php echo e(asset('img/home/periodico.jpg')); ?>)">
                <div class="  text-white px-5 py-6 font-bold text-2xl">
                    <p>educaLibre sólo tendrá futuro si nos apoyas. Suscríbete para que podamos seguir investigando y haciendo periodismo de calidad.</p>
                </div>
                <div class="mx-auto">
                    <img class="mx-auto" style="width: 180px;" src="<?php echo e(asset('img/home/logo2b.png')); ?>" alt="">
                </div>
        </div>
        </div>
        
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="container grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="col-span-2 ">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('articles-index')->html();
} elseif ($_instance->childHasBeenRendered('JEIhlfe')) {
    $componentId = $_instance->getRenderedChildComponentId('JEIhlfe');
    $componentTag = $_instance->getRenderedChildComponentTagName('JEIhlfe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JEIhlfe');
} else {
    $response = \Livewire\Livewire::mount('articles-index');
    $html = $response->html();
    $_instance->logRenderedChild('JEIhlfe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                
                <div class=" bg-gray-100 py-8">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('editorial-index')->html();
} elseif ($_instance->childHasBeenRendered('joa1B0H')) {
    $componentId = $_instance->getRenderedChildComponentId('joa1B0H');
    $componentTag = $_instance->getRenderedChildComponentTagName('joa1B0H');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('joa1B0H');
} else {
    $response = \Livewire\Livewire::mount('editorial-index');
    $html = $response->html();
    $_instance->logRenderedChild('joa1B0H', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>
            </div>
        </div>
        
        <div  class="col-span-1">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('secciones-index')->html();
} elseif ($_instance->childHasBeenRendered('9ZWgEFD')) {
    $componentId = $_instance->getRenderedChildComponentId('9ZWgEFD');
    $componentTag = $_instance->getRenderedChildComponentTagName('9ZWgEFD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9ZWgEFD');
} else {
    $response = \Livewire\Livewire::mount('secciones-index');
    $html = $response->html();
    $_instance->logRenderedChild('9ZWgEFD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        
        <!--Boton de ir hacia arriba-->
        <div id="button-up">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
            </svg>
        </div>    
    </div>
</section>    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\educalibre\resources\views/welcome.blade.php ENDPATH**/ ?>