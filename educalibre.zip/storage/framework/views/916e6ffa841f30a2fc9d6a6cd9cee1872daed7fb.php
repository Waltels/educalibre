<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section>
        <div class="bg-cover container grid grid-cols-1 lg:grid-cols-2"style="background-image: url(<?php echo e(asset('img/pages/bg.jpg')); ?>)">
            <div class="  text-white px-5 py-4 font-bold text-2xl">
                <h2>Político Sindical</h2>
            </div>   
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('polsin-index')->html();
} elseif ($_instance->childHasBeenRendered('BoZvA0I')) {
    $componentId = $_instance->getRenderedChildComponentId('BoZvA0I');
    $componentTag = $_instance->getRenderedChildComponentTagName('BoZvA0I');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BoZvA0I');
} else {
    $response = \Livewire\Livewire::mount('polsin-index');
    $html = $response->html();
    $_instance->logRenderedChild('BoZvA0I', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div id="button-up">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
            </svg>
        </div>
    </section>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\educalibre\resources\views/pages/polsin.blade.php ENDPATH**/ ?>