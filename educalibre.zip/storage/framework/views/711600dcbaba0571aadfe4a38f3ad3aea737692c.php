
<a href="<?php echo e(route('home')); ?>">
<img src="<?php echo e(asset('/img/home/logo.png')); ?>" alt="" style="width: 180px;">
</a><?php /**PATH C:\xampp\htdocs\educalibre\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>