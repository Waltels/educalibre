<?php if (isset($component)) { $__componentOriginal3c0448b937bbb1f49ef7cd1a6dd57c31a9deb378 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\EditorLayout::class, ['article' => $article]); ?>
<?php $component->withName('editor-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <h3 class="text-center text-2lx font-bold">OBSERVACIONES DEL ARTÍCULO</h3>
    <hr class="mt-2 mb-6">
    <div class="text-gray-500 px-3">
        <?php echo $article->observation->body; ?>

    </div>
 <?php if (isset($__componentOriginal3c0448b937bbb1f49ef7cd1a6dd57c31a9deb378)): ?>
<?php $component = $__componentOriginal3c0448b937bbb1f49ef7cd1a6dd57c31a9deb378; ?>
<?php unset($__componentOriginal3c0448b937bbb1f49ef7cd1a6dd57c31a9deb378); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\educalibre\resources\views/editor/articles/observation.blade.php ENDPATH**/ ?>