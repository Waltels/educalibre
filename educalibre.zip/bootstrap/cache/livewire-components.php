<?php return array (
  'admin.users-index' => 'App\\Http\\Livewire\\Admin\\UsersIndex',
  'articles-index' => 'App\\Http\\Livewire\\ArticlesIndex',
  'contact-index' => 'App\\Http\\Livewire\\ContactIndex',
  'cultura-index' => 'App\\Http\\Livewire\\CulturaIndex',
  'deporte-index' => 'App\\Http\\Livewire\\DeporteIndex',
  'editor.articles-index' => 'App\\Http\\Livewire\\Editor\\ArticlesIndex',
  'editorial-index' => 'App\\Http\\Livewire\\EditorialIndex',
  'educacion-index' => 'App\\Http\\Livewire\\EducacionIndex',
  'polsin-index' => 'App\\Http\\Livewire\\PolsinIndex',
  'secciones-index' => 'App\\Http\\Livewire\\SeccionesIndex',
);