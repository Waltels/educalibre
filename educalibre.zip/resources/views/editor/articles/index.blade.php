<x-app-layout>
    @livewire('editor.articles-index')
</x-app-layout>